from django.apps import AppConfig


class GsaappConfig(AppConfig):
    name = 'gsaApp'
